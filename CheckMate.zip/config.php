<?php
  define("MYSQL_HOST", "localhost");
  define("MYSQL_USER", "checkmate");
  define("MYSQL_PASS", "checkmate");
  define("MYSQL_DB_NAME", "checkmate");
